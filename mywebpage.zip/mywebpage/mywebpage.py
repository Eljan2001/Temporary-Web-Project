from app import app
import os
def main():
    print(os.getenv('IP', '0.0.0.0'))
    app.run(host=os.getenv('IP', '0.0.0.0'),
    port=int(os.getenv('PORT', 4444)))
if __name__=="__main__":
    main()
