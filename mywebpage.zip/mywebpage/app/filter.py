from .sorter import*
from .amazon import Amazon
class Filter():
    
    def __init__(self,minimum_val,maximum_val,shipping_val,search_val,des_asc,products_amazon,price_cur):
        self.minimum_val = minimum_val
        self.maximum_val = maximum_val
        self.shipping_val = shipping_val 
        self.search_val = search_val
        self.des_asc = des_asc
        self.products_amazon=products_amazon
        self.price_cur = price_cur
        
    def filter_the_products(self):
        if self.minimum_val!='':
            self.minimum_val=int(self.minimum_val)
        else:
            self.minimum_val=0
        if self.maximum_val!='':
            self.maximum_val=int(self.maximum_val)
        else:
            self.maximum_val=1000000
        if self.search_val != '':
            amazon = Amazon()
            self.products_amazon.extend(amazon.search_for_products(self.search_val))
            sorter=Sorter(self.products_amazon,self.price_cur,self.des_asc)
            self.products_amazon = sorter.sort_all()
        else:
            amazon = Amazon()
            self.products_amazon.extend(amazon.search_for_products('computer'))
            sorter=Sorter(self.products_amazon,self.price_cur,self.des_asc)
            self.products_amazon = sorter.sort_all()
        
        return [self.minimum_val ,self.maximum_val,self.shipping_val, self.search_val,self.des_asc,self.products_amazon, self.price_cur]

    def get_minimum_val(self):
        return self.minimum_val

    def get_maximum_val(self):
        return self.maximum_val

    def get_shipping_val(self):
        return self.shipping_val

    def get_search_val(self):
        return self.search_val

    def get_des_asc(self):
        return self.des_asc

    def get_products_amazon(self):
        return self.products_amazon

    def get_price_cur(self):
        return self.price_cur

