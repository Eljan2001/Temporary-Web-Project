from flask import render_template, flash,redirect,url_for, request
from app import app, db
from flask_login import logout_user, login_required, login_user, current_user
from app.models import User
from app.forms import LoginForm, RegistrationForm
from datetime import datetime,timedelta

#my own packages

from .filter import Filter
from .amazon import* 
from .display import Displayer

@app.route('/')
@app.route('/homepage')
@login_required
def homepage():
    return render_template("homepage.html", title='Home Page',computer1_amazon=computer1_amazon)

@app.route('/')
@app.route('/products')
@login_required
def products():

    minimum_val = request.args.get('minimum_val')
    maximum_val = request.args.get('maximum_val')
    shipping_val = request.args.get('shipping_val')
    search_val = request.args.get('search_val')
    des_asc = request.args.get('des_asc')
    price_cur=request.args.get('price_cur')
    products_amazon=[]
    
    displayer = Displayer(minimum_val, maximum_val, shipping_val, search_val, des_asc, products_amazon,price_cur)
    
    filterer = Filter(displayer.get_minimum_val(),displayer.get_maximum_val(),displayer.get_shipping_val(),displayer.get_search_val(),displayer.get_des_asc(),displayer.get_products_amazon(),displayer.get_price_cur())
    
    filterer.filter_the_products() #Filters the products by all properties

    return render_template("products.html" , title='Products', search_val=filterer.get_search_val(), minimum_val=filterer.get_minimum_val(),shipping_val=filterer.get_shipping_val(), maximum_val=filterer.get_maximum_val(),products_amazon=filterer.get_products_amazon(),price_cur=filterer.get_price_cur())

@app.route('/')
@app.route('/login')
@app.route('/login', methods=['GET', 'POST'])
def login():
    delete_val = request.args.get('del_usr')
    afreg = request.args.get('afreg')
    if current_user.is_authenticated:
        if delete_val!="del_usr" and afreg!="afreg":
            return redirect(url_for('homepage'))
        elif delete_val=="del_usr":
            db.session.delete(current_user)
            db.session.commit()
            flash("The user has been deleted successfully")
    form = LoginForm()
    if form.validate_on_submit():
        user = User.query.filter_by(username=form.username.data).first()
        if user is None or not user.check_password(form.password.data):
            flash('Invalid username or password')
            return redirect(url_for('login'))
        login_user(user, remember=form.remember_me.data)
        return redirect(url_for('homepage'))
    return render_template('login.html', title='Sign In', form=form)
@app.route('/logout')
def logout():
    logout_user()
    return redirect(url_for('homepage'))
@app.route('/register', methods=['GET', 'POST'])
def register():
    if current_user.is_authenticated:
        return redirect(url_for('homepage'))
    form = RegistrationForm()
    if form.validate_on_submit():
        user = User(username=form.username.data, email=form.email.data)
        user.set_password(form.password.data)
        db.session.add(user)
        db.session.commit()
        flash('Your registration was successful!')
        return redirect(url_for('login') + "?afreg=afreg")
    return render_template('register.html', title='Register', form=form)
@app.route('/user/<username>')
@login_required
def user(username):
    user = User.query.filter_by(username=username).first_or_404()
    d=datetime.now()
    x=d - timedelta(microseconds=d.microsecond)
    return render_template('user.html', user=user,title='Profile' , date=x)
