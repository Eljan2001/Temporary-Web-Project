from .webengine import*
class Amazon(Webscraper):
    def __init__(self):
        browser.get("https://www.amazon.com")

    def search_for_products(self,search_product):
        wait = WebDriverWait(browser, 10)
        try:
            search = wait.until(EC.visibility_of_element_located((By.ID, "twotabsearchtextbox")))
        except:
            search = wait.until(EC.visibility_of_element_located((By.ID, "nav-bb-search")))
        search.clear()
        search.send_keys(search_product)
        search.send_keys(Keys.RETURN)
        sleep(1.5)
        results=[]
        i=2
        try:
            dismiss = WebDriverWait(browser, 10).until(EC.visibility_of_element_located((By.XPATH,'//input[@class="a-button-input"]')))
            dismiss.click()
            browser.execute_script("window.scrollTo(0, 3000);")
            browser.execute_script("window.scrollTo(3000, 0);")
        except:
            browser.execute_script("window.scrollTo(0, 3000);")
            browser.execute_script("window.scrollTo(3000, 0);")
        while i<6:
            try:
                sleep(1.5)
                product = browser.find_element(By.XPATH, './/div[@data-index="{}"]'.format(i))
                picture = browser.find_element(By.XPATH,'.//img[@data-image-index="{}"]'.format(i))
                product_link = product.find_element(By.XPATH,'.//a[@class="a-link-normal s-no-outline"]')
                description= product.find_element(By.XPATH,'.//h2[@class="a-size-medium a-spacing-none a-color-base a-text-normal"]')
                try:
                    price=product.find_element(By.XPATH,'.//span[@class="a-price"]')
                    price_int = product.find_element(By.XPATH,'.//span[@class="a-price-whole"]')
                    results.append([picture.get_attribute('src'), description.text, product_link.get_attribute('href'), str(price.text),int(price_int.text),-1])
                    i+=1
                except:
                    results.append([picture.get_attribute('src'),description.text,product_link.get_attribute('href'), -1, -1,-1])
                    i+=1
                    continue
            except:
                sleep(1.5)
                product = browser.find_element(By.XPATH, '//div[@data-index="{}"]'.format(i))
                picture = browser.find_element(By.XPATH,'//img[@data-image-index="{}"]'.format(i))
                product_link = product.find_element(By.XPATH,'.//a[@class="a-link-normal a-text-normal"]')
                description= product.find_element(By.XPATH,'.//h2[@class="a-size-medium a-spacing-none a-color-base a-text-normal"]')
                try:
                    price=product.find_element(By.XPATH,'.//span[@class="a-price"]')
                    price_int = product.find_element(By.XPATH,'.//span[@class="a-price-whole"]')
                    results.append([picture.get_attribute('src'), description.text, product_link.get_attribute('href'), str(price.text),int(price_int.text),-1])
                    i+=1
                except:
                    results.append([picture.get_attribute('src'),description.text,product_link.get_attribute('href'), -1, -1,-1])
                    i+=1
                    continue
                i+=1
                continue
        return results
amazon = Amazon()
computer1_amazon = amazon.search_for_products('computer')

