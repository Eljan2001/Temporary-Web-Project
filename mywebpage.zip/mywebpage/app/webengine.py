from selenium import*
from selenium.webdriver.common.action_chains import ActionChains
from selenium.webdriver.common.keys import Keys
from selenium import webdriver as wb
from webdriver_manager.chrome import ChromeDriverManager
from webdriver_manager.firefox import GeckoDriverManager
from selenium.webdriver.firefox.service import Service
from selenium.webdriver.firefox.options import Options
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC

from random import*
import os
from time import sleep
from selenium.webdriver.firefox.options import*
#os.environ['MOZ_HEADLESS']='1'

# Initialize WebDriver with the correct Service setup
try:
    service = Service(GeckoDriverManager().install())
except:
    service = Service(r".\app\drivers\geckodriver.exe")
browser = wb.Firefox(service=service)
class Webscraper():
    def __init__(self):
        pass
    def search_for_products(self):
        pass
